//
//  main.cpp
//  Punto fijo Programa #3
//
//  Created by José Manuel Bernal Florencio on 29/03/21.
//

#include <iostream>
#include <complex>

int it, i, j, z, k, coe, l, f, n, u, op, sw, maxit;
double xi, xa, gxi, e, p, b, a, x, fa, fb, fp, tol, x0;
int r[20], g[20], m[20];

using namespace std;

int main ()
{
    cout<<"Polinomio a desarrollar"<<endl<<endl;
    cout<<"Dijite el grado de la ecuacion: ";
cin>>n;

    for(i=0;i<=n;i++)
    {
        cout<<"Dijite el coeficiente numero "<<i<< ": ";
    cin>>g[i];
        cout<<endl;
    }

    cout<<"El polinomio es: ";
        for(j=0;j<=n;j++)
        {
        cout<<g[j]<<"x^"<<j;
        }
    cout<<endl<<"Ingrese el valor de x0: ";
    cin>>x0;
cout<<"Ingrese la máxima de iteraciones: ";
cin>>maxit;
    cout<<"Ingrese la tolerancia: ";
    cin>>tol;
    
sw=0;
it=0;
xa=0;
    
    while((sw==0)&&(it<=maxit))
    {
        gxi=0;
        for(j=0;j<=n;j++)
        {
        gxi=gxi+g[j]*pow(x0,j);
        }
        xi=gxi;
        e=fabs(xi-x0);

            if(e<=tol)
            {
            sw=1;
            }
            else
            {
            it=it+1;
            x0=xi;
            }
        cout<<i<<"  "<<x0<<"    "<<gxi<<"   "<<e<<" ";
        cout<<endl;
    }
if(sw==1)
{
    cout<<endl<<"La raiz es: "<<xi;
}
else
{
cout<<endl<<"No converge";
}

}
