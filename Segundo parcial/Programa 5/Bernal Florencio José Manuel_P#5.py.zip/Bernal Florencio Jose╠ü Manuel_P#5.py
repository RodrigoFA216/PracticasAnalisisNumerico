#Programa Metodo de la Secante
#José Manuel Bernal Florencio
#Funciones
#   a) f(x)=x^2-6
#   d) f(x)=2xcos(2x)-(x-2)^2
#   j) f(x)=x+1-2sin(pix)

import math

def main():
    print ("\n****Programa que calcula raices por el metodo de la Secante****")
    a=float(input("Dame el primer punto: "))
    b=float(input("Dame el segunto punto: "))
    tole=float(input("Dame la tolerancia permitida o el error: "))
    limite=int(input("Dame el limite de las veces que se va a hacer esta cuenta: "))
    cont1=1
    fc=-98
    while ((abs(fc)>tole) and (cont1<=limite)):
        fa=funciondada(a)
        fb=funciondada(b)
        c= b-(fb*((b-a)/(fb-fa)))
        cont1=cont1+1
        fc=funciondada(c)
        a=b
        b=c
    if (abs(fc)<=tole):
        print("\n La raiz esta en ", c, " y su valor es ", fc)
        print("Se hizo en ", cont1, "iteraciones")
    if (cont1>=limite):
        print ("Faltaron mas iteraciones")
    print ("\n Fin del programa")

def funciondada(x):
    #salida=pow(x,2)-6
    #salida=(2*x*math.cos(2*x))-(pow((x-2),2))
    #salida=x+1-(2*math.sin(math.pi*x))
    salida=(pow(x,3))-(2*pow(x,2))-(5*x)-8
    return salida

main()
