#Programa Metodo de Newton-Rhapson
#José Manuel Bernal Florencio
#Funciones
#   a) f(x)=x^2-6
#   d) f(x)=2xcos(2x)-(x-2)^2
#   j) f(x)=x+1-2sin(pix)

import math

def poli(x):
    #y=pow(x,2)-6
    #y=(2*x*math.cos(2*x))-(pow((x-2),2))
    #y=x+1-(2*math.sin(math.pi*x))
    y=(pow(x,3))-(2*pow(x,2))-(5*x)-8
    return (y)

def deri(x):
    #d=2*x
    #d=(-4*x*math.sin((2*x)))+(2*math.cos(2*x))-(2*(x-2))
    #d=1-2*math.pi*math.cos(math.pi*x)
    d=(3*pow(x,2))-(4*x)-5
    return (d)

print ("****Programa que calcula raices por el Método de Newton-Raphson****")
x=float(input("Dame el valor de inicio: "))
erroru=float(input("Dame la tolerancia permitida o el error: "))
raiz=[ ]
raiz.insert(0,0)
i=0
error=1
cont1=1
while abs(error) > erroru:
    x1=x-(poli(x)/deri(x))
    raiz.append(x1)
    i=i+1
    x=x1
    error=(raiz[i]-raiz[i-1])/raiz[i]
    cont1=cont1+1
    #print (x)
print ("Se hizo en ",cont1," iteraciones")
print ("La raiz esta en: ",x)
print ("\n Fin del programa")
