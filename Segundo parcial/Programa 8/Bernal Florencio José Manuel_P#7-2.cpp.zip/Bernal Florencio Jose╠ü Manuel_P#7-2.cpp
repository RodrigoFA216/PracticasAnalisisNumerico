//Created by Jos� Manuel Bernal Florencio
//Gauss-Jordan

 #include <stdio.h>
 #include <curses.h>
 #include <math.h>
 #include <iostream>
 #include <iomanip>
#include <stdlib.h>

using namespace std;

 int solucion2(int n, double a[15][15],double b[15]);
 int leer_sistema_ec (int *n, double a[15][15],  double b[15] );
 double x[10];

 int  main(void)
  {
   double a[15][15],an[15][15], b[15], orig[15][15] ;
   int   i,j,n,k;
   leer_sistema_ec(&n,a,b);
   cout.setf(ios::fixed);

   for( i= 1; i<= n ;i++)
     {   for (j=1  ; j<= n ; j++)orig[i][j] = a[i][j];  }


   for (i=1; i<= n ; i++)a[i][n+1]= b[i];

   for (k = 1; k <= n ; k++)
    {
     for (j =k ; j <= (n+1) ; j++)
     {
      an[k][j] = a[k][j]/ a[k][k];
      for (i=1 ; i<= n ; i++)
       {
          if( k != i ) an[i][j] =  a[i][j] - a[i][k] * an[k][j] ;
       }
     }
     for( i= 1; i<= n ;i++)
       { for (j=1  ; j<= (n+1) ; j++)a[i][j] = an[i][j]; }

   cout << endl<<endl << " ITERACION No. " << k << endl;
   for (i= 1; i<= n ; i++)
    {cout << endl;
     for (j= 1; j<=(n+1); j++) cout<<"   "<<setprecision(9)<< a[i][j];}
     getch();
    }
  
     cout <<endl<< " \n     SOLUCION   " <<endl;
     for(i=1; i<=n ; i++)
      {
        x[i] = a[i][n+1];
       cout <<endl<<"  X ( "<<i<< " ) = " <<setprecision(10)<< x[i];
      }
  
    solucion2(n,orig,b); getch(); return 1;
   }
   int solucion2(int n,double a[15][15],double b[15])
    {
      double epsi = 0.00001;
      cout.setf(ios::fixed);
     int i,j, bandera=1;
     double res[10], suma2;
     cout<<endl<<endl<< "    ERROR  O RESIDUO EN CADA ECUACION " <<endl;
     for (i= 1; i <= n ; i++)
       {
          suma2 = 0.;  res[i] = 0.;
          for ( j=1 ; j<= n ; j++) suma2 = suma2 + a[i][j]* x[j];
          res[i] = fabs(b[i]- suma2);
          if (res[i]> epsi) bandera  =0;
          cout <<endl<< "     ECUACION "<<i << " = "
          <<setprecision(11)<< res[i];
       }

        if(bandera == 1) return 1;
        return 0;
      }
   int leer_sistema_ec (int *nm, double a[15][15],  double b[15] )
 
   {
     int i,j,n;
     cout<<"cuantas ecuaciones tiene el sistema?: ";
       cin>>n;
     cout << endl<< "LECTURA DE LA MATRIZ DE COEFICIENTES "<<endl;
     for ( i=1; i<=n ; i++)
      {
        for ( j=1 ; j<=n ; j++)
        {
         cout<<"\n PROPORCIONA EL VALOR DEL TERMINO "<<"A ( "<<i << " , "<< j << ") = ";
            cin>>a[i][j];
         }
      }
    for( i=1 ; i<=n ; i++)
     { cout<<" \n TECLEA EL TERMINO B(" << i << ") = "; cin >>b[i];}
    (*nm)= n;    return 0;
   }



