 //METODO DE GAUSS
// Creatd by Jos� Manuel Bernal Florencio
 #include <stdlib.h>
 #include <stdio.h>
#include <curses.h>
 #include <math.h>3
 #include <iostream>
 #include <iomanip>

 using namespace std; 

 int solucion(void);
 int converge(void);
 int converge2(void);
 int n;
 float a[20][20], b[20] ;
 double epsi, suma, x[20],xa[20];

 int main()
  {
   int   i,j,k,kmax;

      cout<<"\n Cuantas ecuaciones tiene el sistema?:  ";
   cin>>n;
      cout<<"\n Ingresa el valor de Epsilon: ";
   cin>>epsi;
   cout<<"\n Ingresa el numero de iteraciones: ";
    cin>>kmax;
 
   for ( i=1; i<=n ; i++)
    {
     for ( j=1 ; j<=n ; j++)
      {
       printf( "\n PROPORCIONA EL VALOR DEL TERMINO A(%2d,%2d)= ",i,j);
       scanf("%f",&a[i][j]);
      }
    }
   for( i=1 ; i<=n ; i++)
   {
     cout<<" \n Ingresa el termino B(%2d) = "<<i;
       cinb[i];
   }

   for (i= 1; i<= n ; i++) xa[i]= x[i]=0. ;
   for (k =1 ; k <= kmax ; k++)
   {
     for (i=1 ; i<= n ; i++)
      {
        suma = 0.;
        for (j=1; j<= n ; j++)
         {
           if( j != i ) suma = suma + a[i][j] * x[j] ;
         }
            x[i]=  (b[i]- suma )/ a[i][i];
        printf(" \n  X(%2d) = %.6f " , i, x[i]);
      }
      getch();
      if( converge() == 2) goto finaltriste;
      if(converge() == 1)
      {
       if(solucion() == 1)
        {
         cout <<"\n Se encontro una solucion que cumple"
              <<" con la presicion propuesta ";
         cout << "\n Los siguientes valores de X(I) satisfacen el sistema";
         for (i=1 ; i <= n ; i++) printf("\n X(%2d) = %.6lf", i, x[i]);
        cout <<endl<<endl;
        return 0;
        }
       }
    }
    
     cout<<"\n Despues de " << kmax << " iteraciones no se encontro"<<" solucion que satisfaga.";
     cout << "\n\n LOS ULTIMOS VALORES DE X(I) CALCULADOS  SON LOS SIGUIENTES";
     for (i=1 ; i <= n ; i++) printf("\n X(%2d) = %.6lf", i, x[i]);
     cout << "\n \n ";getch();
     return 0;
     finaltriste:
     cout << "\n ********  SIN SOLUCION  ********  \n "
          << " EL PROCESO SE HA VUELTO DIVERGENTE " ;
      return 1;
   }

   int solucion()
    {
     int i,j, bandera=1;
     double res[20], suma2;
     for (i= 1; i <= n ; i++)
       {
          suma2 = 0.;
          res[i] = 0.;
          for ( j=1 ; j<= n ; j++) suma2 = suma2 + a[i][j]* x[j];
          res[i] = fabs(b[i]- suma2);
          if (res[i]> epsi) bandera  =0;
       }
        if(bandera == 1) return 1;
        return 0;
      }
    
      int converge()
       {
        int i;
        double difer,maximo = 0. ;
        for( i=1; i<= n; i++)
         {
		  if ( fabs(x[i])>= 9.e5) return 2;
          difer = fabs( x[i]- xa[i]);
          if (difer >maximo) maximo = difer;
         }
        for( i= 1; i<= n ; i++) xa[i]= x[i];
		if ( maximo <= epsi) return 1;
        return 0;
       }
	    

int converge2()
   {
	double suma [10],max;
	int i,j;
	max =0;
	for (i=1;i <=n ;i ++) suma[i] = 0;
	for (i=1; i<= n ; i++)
    {

	 for (j=1; j<= n; j++ )
	 { 
	  if (i != j )  suma [i] = suma [i] + abs(a[i][j]);
	 }
	 suma[i]  =suma[i]/abs(a[i][i]);
	 cout << " \n suma (" << i<< ") = " << suma[i];  
	 if (suma[i]>max ) max = suma [i];
    }
	if (max < 1) { cout <<" \n *****   SI HABRA SOLUCION  *****  \n"; return 1 ;}	 
	cout << "  NO CUMPLE CRITERIO DE CONVERGENCIA NO HABRA SOLUCION "; return 0;
   }






